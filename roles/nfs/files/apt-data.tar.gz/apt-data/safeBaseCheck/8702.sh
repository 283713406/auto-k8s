#!/bin/bash
###                     完整性检查
### Usage:
###         kylincheck <options>
### Example:
###         kylincheck -v
###         kylincheck -c
### Options:
###     -v              查看完整性检查脚本的版本信息
###     -c              检查亚信客户端是否安装、杀毒引擎、病毒库的版本是否最新以及是否有操作系统补丁
###     -l              进入修复区，设置网络白名单模式
###     -n              退出修复区，取消网络限制
###     -r              修复功能，当前可以修复更新系统补丁
###     -h              帮助信息

## 2022.04.18 检查所有项后返回
## 2022.06.09 做成模板形式，增加进程检查

#脚本版本号
Version=2.0.0

#######系统内核组件####基本应用##################桌面基础组件####################桌面环境组件################软件商店##############
#apps=("linux-generic" "kylin-update-desktop-app" "kylin-update-desktop-support" "kylin-update-desktop-ukui" "kylin-software-center")
apps=("")

#########################################以下部分需要基于配置生成#############################################
####操作系统版本检查
os_chk="true"
####软件及补丁检查
app_chk="true"
####进程运行检查
proc_chk="true"
####亚信杀毒检查
ais_chk="true"
ais_alarm_days=8
ais_block_days=14
####用户sudo权限检查
sudopri_chk="true"

##########是否检查###软件包名####是否阻断#####版本检查####检查方式####版本号###################是否阻断
app_vers=()

#############进程名称##############是否阻断
proc_names=()

#######################################生成配置结束##########################################################

esm_pkg_ver="8.2.2120"
#返回值
chk_ret=0

#亚信服务器IP
esm_ip="127.0.0.1"
esm_str=""

apt_ip="127.0.0.1"
kcm_ip="127.0.0.1"


esm_client_vir_version=""
esm_client_eng_version=""

esm_server_vir_version=""
esm_server_eng_version=""
virtus_uptime=0
enginev_uptime=0

function set_ret_warn() {
	if [ $chk_ret -eq 0 ]; then
		chk_ret=10
	fi
}

function set_ret_err() {
	chk_ret=11
}

function version_cmp() {
        big_ver=`echo "$@" | tr " " "\n" | sort -rV | head -n 1`
        test $big_ver != $1
}

###不再使用
function check_static_version() {
        name=$1
        base_ver=$2
        now_ver=`dpkg-query -W $name | awk '{print $2}'`
        version_cmp $now_ver $base_ver
        if [ $? -eq 0 ]; then
		echo -e "应用版本检查;$name需要更新;请更新应用到$base_ver"
		chk_ret=10
                return 1
        else
                return 0
        fi
}

###替代为check_apps_versions，不再使用
function check_static_versions() {
	vchk_ret=
	## 检查包版本，如需增加其它包检测，复制以下四行添加到后面，修改包名和版本
        check_static_version "hedron-client" '1.0.0'
        if [ $? -eq 1 ]; then
                vchk_ret=1
        fi

	## 检查结束
	return $vchk_ret
}



function check_apps_version() {
  fix_app_vers=()
  num_app_size=${#app_vers[*]}
  if [ $[$num_app_size%7] -ne 0 ]; then
    echo -e "失败;脚本参数校验;包版本参数异常;请重新配置包版本列表"
		set_ret_err
    return 1
  fi
  num_app=$[$num_app_size/7]
  for((i=0;i<$num_app;i++))
  do
    # 安装检查
    if [ ${app_vers[7*$i]} != "true" ]; then
      continue
    fi
    app_name=${app_vers[7*$i+1]}
    app_que=`dpkg-query -W $app_name 2>/dev/null`
    if [ $? -ne 0 ]; then
      if [ ${app_vers[7*$i+2]} == "true" ]; then
        set_ret_err
        echo -e "失败;软件及补丁安装检查;软件包$app_name未安装;请安装软件包$app_name;check_apps_version_fix"
      else
        set_ret_warn
        echo -e "风险;软件及补丁安装检查;软件包$app_name未安装;请安装软件包$app_name;check_apps_version_fix"
      fi
      fix_app_vers=("${fix_app_vers[@]}" $app_name)
      continue
    fi
    if [ ${app_vers[7*$i+3]} != "true" ]; then
      echo -e "成功;软件及补丁安装检查;软件包$app_name已安装;"
      continue
    fi
    # 版本检查
    app_ver=`echo $app_que |awk '{print $2}'`
    cmp_op=${app_vers[7*$i+4]}
    cmp_ver=${app_vers[7*$i+5]}
    ret_op=${app_vers[7*$i+6]}
    if [  $cmp_op == "=" ]; then
      if [ $app_ver != $cmp_ver ]; then
        if [ $ret_op == "true" ]; then
          set_ret_err
          echo -e "失败;软件及补丁版本检查;软件包$app_name版本不为$cmp_ver;请安装$cmp_ver版本;check_apps_version_fix"
        else
          set_ret_warn
          echo -e "风险;软件及补丁版本检查;软件包$app_name版本不为$cmp_ver;请安装$cmp_ver版本;check_apps_version_fix"
        fi
        fix_app_vers=("${fix_app_vers[@]}" $app_name)
        continue
      fi
    elif [ $cmp_op == ">=" ]; then
      version_cmp $app_ver $cmp_ver
      if [ $? -eq 0 ]; then
        if [ $ret_op == "true" ]; then
          set_ret_err
          echo -e "失败;软件及补丁安装检查;软件包$app_name需要更新;请更新到$cmp_ver版本;check_apps_version_fix"
        else
          set_ret_warn
          echo -e "风险;软件及补丁安装检查;软件包$app_name需要更新;请更新到$cmp_ver版本;check_apps_version_fix"
        fi
      fi
      fix_app_vers=("${fix_app_vers[@]}" $app_name)
      continue
    fi
    echo -e "成功;软件及补丁版本检查;软件包$app_name版本为$app_ver"
  done
  echo "fix_app_vers:"${fix_app_vers[@]} >> check_fix_cache.txt
}

function check_apps_version_fix(){
  fix_line=$(cat check_fix_cache.txt | grep fix_app_vers)
  fix_list=${fix_line#*:}
  if [ ! -n "$fix_list"  ];then
    echo -e "没有修复项"
    return 1
  fi
  fix_result=0
  num_app_size=${#app_vers[*]}
  num_app=$[$num_app_size/7]
  for((i=0;i<$num_app;i++))
  do
    app_name=${app_vers[7*$i+1]}
    cmp_ver=${app_vers[7*$i+5]}
    if [[ "${fix_list[@]}" =~ "${app_name}" ]];then
      apt update 1>/dev/null 2>&1
      apt install $app_name=$cmp_ver 1>/dev/null 2>&1
      if [ $? -ne 0 ]; then
        echo -e "失败;安装/更新软件及补丁$app_name=$cmp_ver失败，请联系管理员"
        fix_result=1
      else
        echo -e "成功;安装/更新软件及补丁$app_name=$cmp_ver成功"
      fi
    fi
  done
  return $fix_result
}

function check_procs_running() {
  fix_proc_names=()
	num_proc_size=${#proc_names[*]}
  if [ $[$num_proc_size%2] -ne 0 ]; then
    echo -e "失败;脚本参数校验;进程参数异常;请重新配置进程列表"
    set_ret_err
    return 1
  fi
  num_proc=$[$num_proc_size/2]
  for((i=0;i<$num_proc;i++))
	do
		proc_name=${proc_names[2*$i]}
		pret_op=${proc_names[2*$i+1]}
		proc_info=`ps -ef | grep $proc_name | grep -v grep`
		if [ $? -ne 0 ]; then
			if [ $pret_op == "true" ];  then
				set_ret_err
				echo -e "失败;进程运行检查;进程$proc_name未运行;请运行$proc_name版本;check_procs_running_fix"
			else
				set_ret_warn
				echo -e "风险;进程运行检查;进程$proc_name未运行;请运行$proc_name版本;check_procs_running_fix"
			fi
      fix_proc_names=("${fix_proc_names[@]}" $proc_name)
		else
			echo -e "成功;进程运行检查;进程$proc_name已运行"
		fi
	done
  echo "fix_proc_names:"${fix_proc_names[@]} >> check_fix_cache.txt
}

function check_procs_running_fix() {
  fix_line=$(cat check_fix_cache.txt | grep fix_proc_names)
  fix_list=${fix_line#*:}
  if [ ! -n "$fix_list"  ];then
    echo -e "没有修复项"
    return 1
  fi
  fix_result=0
  num_proc_size=${#proc_names[*]}
  num_proc=$[$num_proc_size/2]
  for((i=0;i<$num_proc;i++))
  do
    proc_name=${proc_names[2*$i]}
    if [[ "${fix_list[@]}" =~ "${proc_name}" ]];then
      systemctl start ${proc_name} 1>/dev/null 2>&1
      if [ $? -ne 0 ]; then
        echo -e "失败;启动进程${proc_name}失败，请联系管理员;"
        fix_result=1
      else
        echo -e "成功;启动进程${proc_name}成功"
      fi
    fi
  done

}


function has_update(){
	name=$1
	current=`apt-cache policy ${name} | grep "已安装"`
	newver=`apt-cache policy ${name} | grep "候选"`
	curr=${current##*：}
	newv=${newver##*：}
	#echo $curr
	#echo $newv
	if [ $newv != $curr ]; then
		return 0
	else
		return 1
	fi
}

function update_app(){
	for app in ${apps[*]}
	do
		apt install $app
		if [ $? -ne 0 ];then
			echo -e "系统更新;$app更新失败;请检查网络"
		fi
	done
}

###未使用
function check_app_version(){
	for app in ${apps[*]}
	do
		has_update $app
		if [ $? -eq 0 ]; then
			#echo "$app has update"
			chk_ret=11
		fi
	done
	if [ $chk_ret -ne 0 ]; then
		echo -e "失败;系统补丁检查;系统存在更新;请在控制面板更新系统"
		#return 1
	fi
	check_static_versions
}

###未使用
function check_domain_online(){
	if [ `netstat -tanp 2>/dev/null | grep sssd_be | grep ESTABLISHED | wc -l` -eq 0 ]; then
		echo "domain is offline now!"
	else
    echo "domain is online now~"
	fi
}

###未使用
function check_root_privilege(){
	if [ $EUID -ne 0 ]; then
		echo "This script must be run as root!"
		exit 1
	fi
}

function check_esm_client(){
	esm=`dpkg -l | grep com.ais.esm | cut -d ' ' -f1`
	if [[ -n "$esm" && "$esm" = "ii" ]]; then
		check_static_version "com.ais.esm" $esm_pkg_ver
        	if [ $? -eq 1 ]; then
                	return 1
        	fi
		return 0
	else
		echo -e "失败;亚信安全软件;未检测到亚信安全软件;请尽快安装亚信安全客户端软件"
		set_ret_err
		return 1
	fi
}

###未使用
function check_system(){
	apt update 1>/dev/null 2>/dev/null
	apt list --upgradable 2>/dev/null | tail -n +2 | cut -d "/" -f1 > /usr/bin/.updatePackage
	if test -e /usr/bin/.updatePackage
	then
		rows=$(wc -l /usr/bin/.updatePackage | awk '{print $1}')
		if [ $[rows] -eq 0 ]
		then
			return 0
		else
			return 1
		fi
	else
		return 2
	fi
}

fix_esms=()
function check_esm_version(){
  #stra=`/opt/BDFZ/AIS/ctrlmain -t`
  stra=`/opt/apps/com.ais.esm/files/bin/ctrlmain -t`
  strb=${stra##*update_time\":\"}
  #ut=`echo ${strb%%\"*} | awk '{ print $1}'`
  ut=${strb%%\"*}
  #cur_date=`date +%Y-%m-%d`
	if [ -z "$ut" ]; then
		echo -e "失败;亚信安全软件;病毒库更新时间未找到;请连接服务器更新"
		set_ret_err
		return 1
	fi
  t_get=`date -d "$ut" +%s`
  t_cur=`date +%s`
  delta_time=$[ ($t_cur-$t_get)/86400 ]
  if [ $delta_time -ge $ais_block_days ]; then
    echo -e "失败;亚信安全软件;病毒库$delta_time天未更新;请马上更新病毒库;check_esm_fix"
    set_ret_err
    fix_esms=("${fix_esms[@]}" "update")
    return 1
  elif [ $delta_time -ge $ais_alarm_days ]; then
    echo -e "风险;亚信安全软件;病毒库$delta_time天未更新;请及时更新病毒库;check_esm_fix"
    set_ret_warn
    fix_esms=("${fix_esms[@]}" "update")
    return 1
  fi
}

function check_esm_running(){
	cnt=`ps -ef | grep ais_ | wc -l`
	if [ $cnt -lt 5 ]; then
		echo -e "失败;亚信安全软件;亚信安全软件未运行;请打开杀毒软件;check_esm_fix"
		set_ret_err
    fix_esms=("${fix_esms[@]}" "install")
		return 1
  else
    echo -e "成功;亚信安全软件运行中"
    return 0
	fi
}

function check_esm_fix(){
  fix_line=$(cat check_fix_cache.txt | grep fix_esms)
  fix_list=${fix_line#*:}
  if [ ! -n "$fix_list"  ];then
    echo -e "没有修复项"
    return 1
  fi
  fix_result=0
  if [[ "${fix_list[@]}" =~ "install" ]];then
    systemctl start aisesm 1>/dev/null 2>&1
    if [ $? -ne 0 ]; then
      echo -e "失败;启动亚信安全软件失败，请联系管理员;"
      fix_result=1
    else
      echo -e "成功;启动亚信安全软件成功"
    fi
  fi
  if [[ "${fix_list[@]}" =~ "update" ]];then
    ctrlmain -u pattern 1>/dev/null 2>&1
    if [ $? -ne 0 ]; then
      echo -e "失败;更新病毒库失败，请联系管理员;"
      fix_result=1
    else
      echo -e "成功;更新病毒库成功"
    fi
  fi
  return $fix_result
}

function check_esm_all(){
	#check_esm_client && check_esm_running && check_esm_version
	###亚信包和版本统一到软件和补丁检查中配置
	check_esm_running && check_esm_version
  echo "fix_esms:"${fix_esms[@]} >> check_fix_cache.txt
}

function repair_esm(){
	echo "请打开亚信客户端进行更新"
}

function limit_net(){
	iptables -F
	iptables -X
	iptables -P OUTPUT DROP
	iptables -A OUTPUT -d 127.0.0.1 -j ACCEPT
	getIPErrorcode=$(/opt/apps/com.ais.esm/files/bin/ctrlmain -S | grep -Po '(?<=error_code":\s)\d')
        esm_ip=$(/opt/apps/com.ais.esm/files/bin/ctrlmain -S | grep -Po '(?<=ip":")[0-9].*' | cut -d '"' -f1)
        if [[ $[getIPErrorcode] -eq 0  && -n $getIPErrorcode && -n $esm_ip ]]
        then
                iptables -A OUTPUT -d $esm_ip -j ACCEPT
        fi
	iptables -A OUTPUT -d $apt_ip -j ACCEPT
	iptables -A OUTPUT -d $kcm_ip -j ACCEPT

}

function normal_net(){
	iptables -F
	iptables -X
	iptables -P OUTPUT ACCEPT
}


##检查系统版本为sp1
function check_osversion(){
	osv=`cat /etc/os-release | grep PROJECT_CODENAME=`
	ov=${osv##*=}
	if [ $ov == "v10sp1" ] || [ $ov == "V10SP1" ]; then
		echo -e "成功;操作系统版本检查;操作系统版本为$ov"
		return 0
  else
    echo -e "失败;操作系统版本检查;操作系统错误;请更新操作系统版本"
    set_ret_err
		return 1
	fi
}


##检查已登录用户是否具有sudo权限
function checksudopriv() {
	sudo_chk=0
  logins=`who | awk '{print $1}' | tr "\n" " "`
  for user in $logins
  do
    #groups $user | grep 'sudo' >> /dev/null
    runuser - $user -c "sudo -v" 2>&1 | grep "sudo:" >> /dev/null
    if [ $? -eq 0 ]; then
      echo -e "失败;用户权限检查;用户$user具有管理员权限;请禁用用户登录"
      set_ret_err
      sudo_chk=1
    fi
  done
	return $sudo_chk
}

function check_all() {
  if [ -f "check_fix_cache.txt" ]; then
    rm -f check_fix_cache.txt
  fi
  touch check_fix_cache.txt
	if [ $os_chk == "true" ]; then
    check_osversion
	fi
	if [ $app_chk == "true" ]; then
		check_apps_version
	fi
	if [ $proc_chk == "true" ]; then
		check_procs_running
	fi
	if [  $ais_chk == "true" ]; then
		check_esm_all
	fi
	if [ $sudopri_chk == "true" ]; then
		checksudopriv
	fi
}

function main(){
	case $1 in
	-c)
		check_all
		;;
	-r)
		update_app
		repair_esm
		;;
	-v)
		echo "Version:$Version"
		;;
	-l)
		echo "修复区"
		limit_net
		;;
	-n)
		normal_net
		;;
	-h)
		awk -F'### ' '/^###/ { print $2 }' "$0"
		;;
    -f)
		check_apps_version_fix
		check_procs_running_fix
		check_esm_fix
		;;
  (check_apps_version_fix)
    check_apps_version_fix
    ;;
  (check_procs_running_fix)
    check_procs_running_fix
    ;;
  (check_esm_fix)
    check_esm_fix
    ;;
	*)   
		#echo "未找到该命令! 请使用 kylincheck -h 查看帮助。"
		check_all 
		;;
	esac
	case $chk_ret in
	0)
		return 0
		;;
	10)
		return 1
		;;
	*)
		return -1
		;;
	esac
	#return $chk_ret
}

main $1
